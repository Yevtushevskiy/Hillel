var a = prompt("ведите сумму в $");
a = Number(a);

alert(a*27.15)

