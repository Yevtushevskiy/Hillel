var a = prompt('ведите первое значение');
var b = prompt('ведите второе значение');
if (a==b){
	alert('верно');
}
else {
	alert("не верно")
}