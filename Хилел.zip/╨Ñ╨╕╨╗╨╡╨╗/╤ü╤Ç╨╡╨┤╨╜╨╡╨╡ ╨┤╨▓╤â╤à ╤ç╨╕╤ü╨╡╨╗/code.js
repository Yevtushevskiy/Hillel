var a = prompt("введите первое число");
var b = prompt("введите второе число");
var a = Number(a);
var b = Number(b);
var c = (a+b)/2 ;
alert(c); 